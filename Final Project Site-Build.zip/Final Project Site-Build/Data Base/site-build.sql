/*
SQLyog Ultimate v12.5.0 (64 bit)
MySQL - 10.4.28-MariaDB : Database - site-build
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`site-build` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `site-build`;

/*Table structure for table `login` */

DROP TABLE IF EXISTS `login`;

CREATE TABLE `login` (
  `id` int(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `User_type` tinytext NOT NULL,
  `pw` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `login` */

/*Table structure for table `signup` */

DROP TABLE IF EXISTS `signup`;

CREATE TABLE `signup` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) NOT NULL,
  `cnic` decimal(15,0) NOT NULL,
  `email` varchar(30) NOT NULL,
  `pass` varchar(18) NOT NULL,
  `user_type` tinytext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `signup` */

/*Table structure for table `transactions` */

DROP TABLE IF EXISTS `transactions`;

CREATE TABLE `transactions` (
  `id` int(50) NOT NULL,
  `date` date NOT NULL,
  `action` tinytext NOT NULL,
  `material` tinytext NOT NULL,
  `quantity` varchar(50) NOT NULL,
  `site` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `transactions` */

insert  into `transactions`(`id`,`date`,`action`,`material`,`quantity`,`site`) values 
(0,'2023-09-13','Added Material','','','');

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `cnic` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `pw` varchar(255) NOT NULL,
  `user_type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `user` */

insert  into `user`(`id`,`name`,`cnic`,`email`,`pw`,`user_type`) values 
(11,'hamza','4220194076305','admin@gmail.com','admin','client'),
(12,'Hamza','1234567890','admin@gmail.com','admin','Site-Manager'),
(13,'','','','',''),
(14,'hamza123','4220194076305','admin@gmail.com','admin','Site-Manager'),
(15,'','','','',''),
(16,'','','','',''),
(17,'','','','',''),
(18,'','','','',''),
(19,'yousuf','0123456789','yousuf@gmail.com','123','Administrator'),
(20,'yousuf','0123456789','yousuf@gmail.com','admin','Administrator'),
(21,'khan','789789789','khan@gmail.com','ADMIN','Site-Manager'),
(22,'','','','',''),
(23,'','','','',''),
(24,'khan','789789789','khan@gmail.com','132','Site-Manager'),
(25,'Arai','4341346743','Arai@gmail.com','admin','Supplier');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
