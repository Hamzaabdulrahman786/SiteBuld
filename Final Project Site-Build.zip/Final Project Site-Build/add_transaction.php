<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "site-build";

/////////////////GET POST VALUES//////////////////
$material = $_POST["material"];
$quantity = $_POST["quantity"];
$site = $_POST["site"];

/////////////////GET POST VALUES//////////////////

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Handle the form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $action = "Added Material"; // You can customize this as needed
    $material = $_POST["material"];
    $quantity = $_POST["quantity"];
    $site = $_POST["site"];
    $date = date("Y-m-d H:i:s"); // Get the current date and time

    // Insert the data into the database
    $sql = "INSERT INTO transactions (date, action, material, quantity, site) VALUES ('$date', '$action', '$material', '$quantity', '$site')";
    if (mysqli_query($conn, $sql)) {
        echo "Transaction added successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}

// Close the database connection
mysqli_close($conn);
?>
<?php
// Fetch and display recent transactions
$sql = "SELECT * FROM transactions ORDER BY date DESC LIMIT 10"; // Adjust the query as needed
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $row["date"] . "</td>";
        echo "<td>" . $row["action"] . "</td>";
        echo "<td>" . $row["material"] . "</td>";
        echo "<td>" . $row["quantity"] . "</td>";
        echo "<td>" . $row["site"] . "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='5'>No transactions found</td></tr>";
}

// Close the database connection
mysqli_close($conn);
?>
