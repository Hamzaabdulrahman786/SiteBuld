<?php

/*
Get ID of The Last Inserted Record
*/

$name = $_POST['name'];
$cnic = $_POST['cnic'];
$email = $_POST['email'];
$pw = $_POST['pw'];
$user_type = $_POST['user_type'];

$servername = "localhost:3306";
$username = "root";
$password = "";
$dbname = "site-build";

// Create a connection to the database
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

$sql = "INSERT INTO user (name, cnic, email, pw, user_type)
VALUES ('$name', '$cnic', '$email', '$pw', '$user_type')";

if (mysqli_query($conn, $sql)) {
  $last_id = mysqli_insert_id($conn);
  echo "Congratulations you are now registerd in our system.";
} else {
  echo "Error: " . mysqli_error($conn);
}

mysqli_close($conn);

?>


