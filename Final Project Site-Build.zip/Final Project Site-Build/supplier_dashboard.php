<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Supplier Dashboard</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="styles.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg" style="background-color: #f8b32a;">
        <div class="container">
          <a class="navbar-brand" href="client-dashboard.html">
            <img src="logoimage_for_nav_left_edit.png" alt="Logo" width="208" height="50" class="d-inline-block align-text-top">
          </a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                <a class="nav-link" href="Login.html" style="color: #000;"><button style="background-color: #f8b32a;">Log out</button></a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
  
    <div class="container mt-4">
    <div class="row">
      <div class="col-md-6">
        <h2>Add Material to Construction Site</h2>
        <form id="addMaterialForm">
          <!-- Form fields for adding materials -->
          <!-- Example: Material name, quantity, site ID, etc. -->
          <button type="submit" class="btn btn-primary">Add Material</button>
        </form>
      </div>
      <div class="col-md-6">
        <h2>Fulfill Construction Site Demands</h2>
        <form id="fulfillDemandForm">
          <!-- Form fields for fulfilling site demands -->
          <!-- Example: Site ID, material name, quantity, etc. -->
          <button type="submit" class="btn btn-success">Fulfill Demand</button>
        </form>
      </div>
    </div>
    <br><br><br>
    <form id="addMaterialForm">
    <div class="form-group" method = POST>
        <label for="material">Material:</label>
        <input type="text" class="form-control" id="material" name="material" required>
    </div>
    <div class="form-group">
        <label for="quantity">Quantity:</label>
        <input type="number" class="form-control" id="quantity" name="quantity" required>
    </div>
    <div class="form-group">
        <label for="site">Site:</label>
        <input type="text" class="form-control" id="site" name="site" required>
    </div>
    <button type="submit" class="btn btn-primary">Add Material</button>
    <br><br><br>
  </form>
    <div class="row mt-4">
      <div class="col-md-12">
        <h2>Recent Transactions</h2>
        <table class="table">
          <thead>
            <tr>
              <th>Material</th>
              <th>Quantity</th>
              <th>Site</th>
            </tr>
          </thead>
               <tbody id="transactionTable">
                <!-- PHP code to generate table rows goes here -->
               </tbody>
        </table>
      </div>
    </div>
  </div>




      <br><br><br><br>
  <footer style="background-color: #f8b32a;">
    <div class="container py-4">
      <div class="row">
        <div class="col-md-6">
          <h4>Follow Us</h4>
          <p>Stay connected with us on social media.</p>
          <ul class="list-unstyled d-flex">
            <li class="mr-3"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
            <li class="mr-3"><a href="#"><i class="fab fa-twitter"></i></a></li>
            <li class="mr-3"><a href="#"><i class="fab fa-instagram"></i></a></li>
            <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
          </ul>
        </div>
        <div class="col-md-6 text-md-right">
          <p>&copy; 2023 SoftXOne. All rights reserved.</p>
        </div>
      </div>
    </div>
  </footer>
  <script>document.getElementById("addMaterialForm").addEventListener("submit", function (e) {
    e.preventDefault();

    // Fetch form data
    const material = document.getElementById("material").value;
    const quantity = document.getElementById("quantity").value;
    const site = document.getElementById("site").value;

    // Send data to the server using AJAX
    fetch("add_transaction.php", {
        method: "POST",
        body: new URLSearchParams({ material, quantity, site }),
        headers: {
            "Content-Type": "application/x-www-form-urlencoded",
        },
    })
        .then((response) => response.text())
        .then((message) => {
            // Display a success message or handle errors
            alert(message);

            // Clear the form fields
            document.getElementById("material").value = "";
            document.getElementById("quantity").value = "";
            document.getElementById("site").value = "";

            // Reload or update the recent transactions table
            // You can fetch the updated data from the server here
        })
        .catch((error) => {
            console.error("Error:", error);
        });
});
</script>
  <!-- Bootstrap JS and your custom scripts -->
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script src="scripts.js"></script>
</body>
</html>
