<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Site Manager Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg" style="background-color: #f8b32a;">
        <div class="container">
          <a class="navbar-brand" href="client-dashboard.html">
            <img src="logoimage_for_nav_left_edit.png" alt="Logo" width="208" height="50" class="d-inline-block align-text-top">
          </a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                <a class="nav-link" href="Login.html" style="color: #000;"><button style="background-color: #f8b32a;">Log out</button></a>
              </li>
            </ul>
          </div>
        </div>
      </nav>

  
  <div class="container mt-4">
    <div class="row">
      <div class="col-md-8">
        <h2>Daily Progress</h2>
        <form>
          <div class="mb-3">
            <label for="progressTextarea" class="form-label">Enter Progress:</label>
            <textarea class="form-control" id="progressTextarea" rows="4"></textarea>
          </div>
          <div class="mb-3">
            <label for="imageInput" class="form-label">Upload Images:</label>
            <input type="file" class="form-control" id="imageInput" multiple>
          </div>
          <button type="submit" class="btn btn-primary">Submit Progress</button>
        </form>
      </div>
      
      <div class="col-md-4">
        <h2>Tasks</h2>
        <ul class="list-group">
          <li class="list-group-item d-flex justify-content-between align-items-center">
            Task 1
            <input type="checkbox">
          </li>
          <li class="list-group-item d-flex justify-content-between align-items-center">
            Task 2
            <input type="checkbox">
          </li>
          <li class="list-group-item d-flex justify-content-between align-items-center">
            Task 3
            <input type="checkbox">
          </li>
          <li class="list-group-item d-flex justify-content-between align-items-center">
            Task 4
            <input type="checkbox">
          </li>
          <li class="list-group-item d-flex justify-content-between align-items-center">
            Task 5
            <input type="checkbox">
          </li>
          <li class="list-group-item d-flex justify-content-between align-items-center">
            Task 6
            <input type="checkbox">
          </li>
          <li class="list-group-item d-flex justify-content-between align-items-center">
            Task 7
            <input type="checkbox">
          </li>
          <li class="list-group-item d-flex justify-content-between align-items-center">
            Task 8
            <input type="checkbox">
          </li>
          <li class="list-group-item d-flex justify-content-between align-items-center">
            Task 9
            <input type="checkbox">
          </li>
          <li class="list-group-item d-flex justify-content-between align-items-center">
            Task 10
            <input type="checkbox">
          </li>
          <li class="list-group-item d-flex justify-content-between align-items-center">
            Task 11
            <input type="checkbox">
          </li>
          <li class="list-group-item d-flex justify-content-between align-items-center">
            Task 12
            <input type="checkbox">
          </li>
        </ul>
      </div>
    </div>
  </div>
  <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

        
  <footer style="background-color: #f8b32a;">
    <div class="container py-4">
      <div class="row">
        <div class="col-md-6">
          <h4>Follow Us</h4>
          <p>Stay connected with us on social media.</p>
          <ul class="list-unstyled d-flex">
            <li class="mr-3"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
            <li class="mr-3"><a href="#"><i class="fab fa-twitter"></i></a></li>
            <li class="mr-3"><a href="#"><i class="fab fa-instagram"></i></a></li>
            <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
          </ul>
        </div>
        <div class="col-md-6 text-md-right">
          <p>&copy; 2023 SoftXOne. All rights reserved.</p>
        </div>
      </div>
    </div>
  </footer>
  
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
