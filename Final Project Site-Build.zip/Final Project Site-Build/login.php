<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "site-build";

/////////////////GET POST VALUES//////////////////
$email = $_POST["email"];
$user_type = $_POST["user_type"];
$pw = $_POST["pw"];

/////////////////GET POST VALUES//////////////////

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM user where email = '".$email."' AND user_type ='".$user_type."' AND pw='".$pw."'";

$result = mysqli_query($conn, $sql);

if ($result) { // Check if the query was successful
  if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
      echo "OK you are logged in.<br>";
      $_SESSION['loggedin'] = "YES";
      $_SESSION['name'] = $row["name"];

      // Redirect users based on their user_type
      switch ($user_type) {
        case "Client":
          header("Location: client_dashboard.php");
          break;
        case "Administrator":
          header("Location: admin_dashboard.php");
          break;
        case "Supplier":
          header("Location: supplier_dashboard.php");
          break;
        case "Site Manager":
          header("Location: site_manager_dashboard.php");
          break;
        default:
          // Handle other user types or provide a default redirection
          header("Location: default_dashboard.php");
          break;
      }
    }
  } else {
    echo "Sorry email or password does not match in our system<br>";
    echo "Please register<br>";
    $_SESSION['loggedin'] = "NO";
  }
} else {
  echo "Query failed: " . mysqli_error($conn); // Print the error message if the query fails
}

mysqli_close($conn);
?>

</body>
</html>
