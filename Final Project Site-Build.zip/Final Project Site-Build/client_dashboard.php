<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project Progress Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg" style="background-color: #f8b32a;">
        <div class="container">
          <a class="navbar-brand" href="client-dashboard.html">
            <img src="logoimage_for_nav_left_edit.png" alt="Logo" width="208" height="50" class="d-inline-block align-text-top">
          </a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                <a class="nav-link" href="Login.html" style="color: #000;"><button style="background-color: #f8b32a;">Log out</button></a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <div class="container mt-5">
        <div class="row">
            <div class="col-md-6">
                <h2>Project Progress</h2>
                <div class="progress">
                    <div class="progress-bar" role="progressbar" style="width: 75%;" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">75%</div>
                </div>
                <h3>Done Work</h3>
                <ul class="list-group">
                    <li class="list-group-item">Task A - Completed on: Aug 15, 2023</li>
                    <li class="list-group-item">Task B - Completed on: Aug 20, 2023</li>
                </ul>
            </div>
            <div class="col-md-6">
                <h2>Remaining Work Timeline</h2>
                <ul class="list-group">
                    <li class="list-group-item">Task 1 - Due on: Aug 30, 2023</li>
                    <li class="list-group-item">Task 2 - Due on: Sep 10, 2023</li>
                    <li class="list-group-item">Task 3 - Due on: Sep 15, 2023</li>
                </ul>
            </div>
        </div>
    </div>
    <br>
    <div class="container mt-5">
      <center><h1 id="Progress Images">Progress Images</h1></center>
      <br>
      <br>
      <div class="row">
        <div class="col-md-4 mb-4">
          <a href="#">
            <img src="Expertise and Experience.png" alt="Service 1" class="img-fluid service-img">
          </a>
          <p>Expertise and Experience</p>
        </div>
        <div class="col-md-4 mb-4">
          <a href="#">
            <img src="Customization and Personalization.jpg" alt="Service 1" class="img-fluid service-img">
          </a>
          <p>Customization and Personalization</p>
        </div>
        <div class="col-md-4 mb-4">
          <a href="#">
            <img src="Strategic Design Process.png" alt="Service 1" class="img-fluid service-img">
          </a>
          <p>Strategic Design Process</p>
        </div>
        <div class="col-md-4 mb-4">
          <a href="#">
            <img src="Responsive and Mobile-First Approach.png" alt="Service 1" class="img-fluid service-img">
          </a>
          <p>Responsive and Mobile-First Approach</p>
        </div>
        <div class="col-md-4 mb-4">
          <a href="#">
            <img src="Timely Project Delivery.jpg" alt="Service 1" class="img-fluid service-img">
          </a>
          <p>Timely Project Delivery</p>
        </div>
        <div class="col-md-4 mb-4">
          <a href="#">
            <img src="Post-Launch Support and Maintenance.jpg" alt="Service 1" class="img-fluid service-img">
          </a>
          <p>Post-Launch Support and Maintenance</p>
        </div>
      </div>
    </div>
    <br>
    <br>
    <div class="container mt-5">
      <center><h1>Leave a Message for the Management</h1></center>
      <form>
        <div class="form-group">
          <label for="name">Name:</label>
          <input type="text" class="form-control" id="name" name="name" required>
        </div>
        <div class="form-group">
          <label for="email">Email:</label>
          <input type="email" class="form-control" id="email" name="email" required>
        </div>
        <div class="form-group">
          <label for="phone">Phone Number:</label>
          <input type="tel" class="form-control" id="phone" name="phone" required>
        </div>
        <div class="form-group">
          <label for="message">Message:</label>
          <textarea class="form-control" id="message" name="message" rows="4" required></textarea>
        </div><br>
        <button type="submit" class="btn btn-primary" style="background-color: #f8b32a;" >Submit</button>
      </form>
    </div>
    <br>
    <br>
    
    <footer style="background-color: #f8b32a;">
      <div class="container py-4">
        <div class="row">
          <div class="col-md-6">
            <h4>Follow Us</h4>
            <p>Stay connected with us on social media.</p>
            <ul class="list-unstyled d-flex">
              <li class="mr-3"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
              <li class="mr-3"><a href="#"><i class="fab fa-twitter"></i></a></li>
              <li class="mr-3"><a href="#"><i class="fab fa-instagram"></i></a></li>
              <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
            </ul>
          </div>
          <div class="col-md-6 text-md-right">
            <p>&copy; 2023 SoftXOne. All rights reserved.</p>
          </div>
        </div>
      </div>
    </footer>
</body>
</body>
</html>
